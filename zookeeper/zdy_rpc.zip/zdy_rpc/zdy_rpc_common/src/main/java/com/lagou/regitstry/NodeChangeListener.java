package com.lagou.regitstry;

public interface NodeChangeListener {

    void notify(String nodeInfo);
}
