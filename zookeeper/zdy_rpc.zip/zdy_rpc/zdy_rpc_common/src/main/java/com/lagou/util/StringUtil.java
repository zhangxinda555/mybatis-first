package com.lagou.util;

public class StringUtil {

    public static Integer getPortFromPath(String path){
        if (path == null){
            return null;
        }

        int i = path.lastIndexOf(".");
        String portPath = path.substring(i + 1);

        if ("".equals(portPath)){
            return null;
        }

        return Integer.valueOf(portPath);


    }
}
