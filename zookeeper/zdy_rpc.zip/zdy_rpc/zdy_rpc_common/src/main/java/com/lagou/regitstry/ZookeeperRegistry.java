package com.lagou.regitstry;

public interface ZookeeperRegistry {


    void registry();


    void unregistry();

    void subscribe();
}
