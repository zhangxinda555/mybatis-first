package com.lagou.enums;

public enum RequestModel {

    All,

    LoadingBalance
}
