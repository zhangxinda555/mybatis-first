import org.apache.curator.RetryPolicy;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.framework.recipes.cache.ChildData;
import org.apache.curator.framework.recipes.cache.PathChildrenCache;
import org.apache.curator.framework.recipes.cache.PathChildrenCacheEvent;
import org.apache.curator.framework.recipes.cache.PathChildrenCacheListener;
import org.apache.curator.retry.ExponentialBackoffRetry;

public class TestListen {

    public static void main(String[] args) throws Exception {
        RetryPolicy retryPolicy = new ExponentialBackoffRetry(1000,3);

        CuratorFramework curatorFramework = CuratorFrameworkFactory.builder()
                .connectString("49.234.146.31:2181")
                .sessionTimeoutMs(50000)
                .connectionTimeoutMs(2000)
                .retryPolicy(retryPolicy)
                .namespace("netty")
                .build();


        curatorFramework.start();

        PathChildrenCache pathChildrenCache = new PathChildrenCache(curatorFramework,"/",true);
        pathChildrenCache.getListenable().addListener(new PathChildrenCacheListener() {
            @Override
            public void childEvent(CuratorFramework curatorFramework, PathChildrenCacheEvent pathChildrenCacheEvent) throws Exception {
                System.out.println("事件类型："+pathChildrenCacheEvent.getType());
                ChildData data = pathChildrenCacheEvent.getData();
                if (data != null){
                    System.out.println("变化的节点："+data.getPath());
                    System.out.println("变化的节点数据："+data.getData().toString());
                }
            }
        });

        pathChildrenCache.start();


        while (true){

            Thread.sleep(4000000);
        }
    }
}
