import org.apache.curator.RetryPolicy;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.framework.recipes.cache.ChildData;
import org.apache.curator.framework.recipes.cache.PathChildrenCache;
import org.apache.curator.framework.recipes.cache.PathChildrenCacheEvent;
import org.apache.curator.framework.recipes.cache.PathChildrenCacheListener;
import org.apache.curator.retry.ExponentialBackoffRetry;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.data.Stat;

import java.util.List;

public class TestDemo {

    public static void main(String[] args) throws Exception {
        RetryPolicy retryPolicy = new ExponentialBackoffRetry(1000,3);

        CuratorFramework curatorFramework = CuratorFrameworkFactory.builder()
                .connectString("49.234.146.31:2181")
                .sessionTimeoutMs(5000)
                .connectionTimeoutMs(2000)
                .retryPolicy(retryPolicy)
                .namespace("netty")
                .build();


        curatorFramework.start();

        PathChildrenCache pathChildrenCache = new PathChildrenCache(curatorFramework,"/",true);
        pathChildrenCache.getListenable().addListener(new PathChildrenCacheListener() {
            @Override
            public void childEvent(CuratorFramework curatorFramework, PathChildrenCacheEvent pathChildrenCacheEvent) throws Exception {
                System.out.println("事件类型："+pathChildrenCacheEvent.getType());
                ChildData data = pathChildrenCacheEvent.getData();
                if (data != null){
                    System.out.println("变化的节点："+data.getPath());
                    System.out.println("变化的节点数据："+data.getData().toString());
                }
            }
        });

        pathChildrenCache.start();
        List<String> strings = curatorFramework.getChildren().forPath("/");
        if (!strings.isEmpty()){

            //操作存放节点的数据时需要加锁
           // try {
                //boolean b = reentrantLock.writeLock().tryLock();
                //if (b){
                    for (String string : strings) {

                        System.out.println("netty"+string);

                        //byte[] bytes = curatorFramework.getData().forPath(string);
                        //String s = bytes.toString();
                        //System.out.println(s);
                    }
                //}//
            //}finally {
               // reentrantLock.writeLock().unlock();
            //}


        }



        String s = curatorFramework.create().creatingParentsIfNeeded().withMode(CreateMode.EPHEMERAL).forPath("/zxd1");

        System.out.println("创建节点："+s);

        Thread.sleep(1000);


        Stat stat = curatorFramework.setData().forPath("/zxd1","第一次".getBytes());
        System.out.println("修改数据："+stat);

        Thread.sleep(1000);


        Stat stat1 = curatorFramework.setData().forPath("/zxd1","第二次".getBytes());
        System.out.println("修改数据："+stat1);

        Thread.sleep(1000);


        while (true){
            Thread.sleep(30000000);
        }




    }
}
