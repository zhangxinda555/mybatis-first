package com.lagou.service;

import com.lagou.annotation.Service;


@Service
public class UserServiceImpl implements UserService {

    public String sayHello(String word) {
        System.out.println("调用成功--参数 "+word);
        return "调用成功--参数 "+word;
    }

    public String getData(Object port,String s){
        System.out.println("调用成功:success"+"++++++参数："+port.toString()+","+s);
        return "我是端口为："+8909+"的服务器调用成功 \n";
    }

}
