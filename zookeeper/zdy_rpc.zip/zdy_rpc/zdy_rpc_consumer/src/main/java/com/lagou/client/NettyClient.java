package com.lagou.client;

import com.lagou.model.RpcResponse;
import com.lagou.util.RpcDecoder;
import com.lagou.util.RpcEncoder;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;

public class NettyClient {

    private int port;
    private String ip;

    private ChannelFuture channel;

    private UserClientHandler userClientHandler;


    public NettyClient(String ip,int port){
        this.port = port;
        this.ip = ip;
        if (this.ip == null || "".equals(ip)){
            this.ip= "127.0.0.1";
        }

    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public ChannelFuture getChannel() {
        return channel;
    }

    public void setChannel(ChannelFuture channel) {
        this.channel = channel;
    }

    public UserClientHandler getUserClientHandler() {
        return userClientHandler;
    }

    public void setUserClientHandler(UserClientHandler userClientHandler) {
        this.userClientHandler = userClientHandler;
    }

    @Override
    public String toString() {
        return "NettyClient{" +
                "port=" + port +
                ", ip='" + ip + '\'' +
                ", channel=" + channel +
                ", userClientHandler=" + userClientHandler +
                '}';
    }

    //初始化netty客户端
    public Channel initClient() throws InterruptedException {


        EventLoopGroup group = new NioEventLoopGroup();
        userClientHandler = new UserClientHandler();
        Bootstrap bootstrap = new Bootstrap();
        bootstrap.group(group)
                .channel(NioSocketChannel.class)
                .option(ChannelOption.TCP_NODELAY, true)
                .handler(new ChannelInitializer<SocketChannel>() {
                    protected void initChannel(SocketChannel ch) throws Exception {
                        ChannelPipeline pipeline = ch.pipeline();
                        pipeline.addLast(new RpcDecoder(RpcResponse.class));
                        pipeline.addLast(new RpcEncoder());
                        //pipeline.addLast(new RpcConsumer.NettyConnectManagerHandler());
                        pipeline.addLast(userClientHandler);
                    }
                });

        ChannelFuture channel = bootstrap.connect(ip, port).sync();

        this.channel = channel;
        return channel.channel();

    }





}
