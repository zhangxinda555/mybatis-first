package com.lagou.client;

import com.lagou.enums.RequestModel;
import com.lagou.model.RpcRequest;
import com.lagou.util.StringUtil;
import org.apache.curator.RetryPolicy;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.framework.recipes.cache.ChildData;
import org.apache.curator.framework.recipes.cache.PathChildrenCache;
import org.apache.curator.framework.recipes.cache.PathChildrenCacheEvent;
import org.apache.curator.framework.recipes.cache.PathChildrenCacheListener;
import org.apache.curator.retry.ExponentialBackoffRetry;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

public class RpcConsumer extends AbstractRpConsumer {

    //创建线程池对象
    private static ExecutorService executor = Executors.newFixedThreadPool(6);

    private static CuratorFramework curatorFramework;


    //对所有服务器发送请求还是负载均衡模式
    private String currentModel = "LoadingBalance";
    private  String host;

    public RpcConsumer(String host) {

        this.host = host;

    }

    //1.创建一个代理对象 providerName：UserService#sayHello are you ok?
    public Object createProxy(final Class<?> serviceClass, final String providerName) {
        //借助JDK动态代理生成代理对象
        return Proxy.newProxyInstance(Thread.currentThread().getContextClassLoader(), new Class<?>[]{serviceClass}, new InvocationHandler() {
            public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {


                    List<UserClientHandler> userClientHandlers = new ArrayList<>();

                    //封装请求的数据
                    RpcRequest request = new RpcRequest();
                    request.setClassName(serviceClass.getName());
                    request.setMethodName(method.getName());
                    request.setParameters(args);
                    request.setRequestId(UUID.randomUUID().toString());
                    Class<?>[] parameterTypes = method.getParameterTypes();
                    request.setParameterTypes(parameterTypes);
                    try {
                        //客户端请求所有服务
                        if (currentModel.equals(RequestModel.All.name())){
                            nettyClientHashMap.entrySet().forEach(e->{
                                    NettyClient nettyClient = e.getValue();

                                    //RsponseFuture rsponseFuture = new RsponseFuture();
                                    userClientHandlers.add(nettyClient.getUserClientHandler());

                                    postRequest(request,nettyClient.getChannel() ,null);


                            });

                        }//客户端实现负载均衡
                        else if (currentModel.equals(RequestModel.LoadingBalance.name())){

                            NettyClient nettyClient = getCompareTimeResult();

                            userClientHandlers.add(nettyClient.getUserClientHandler());
                            TimeRecord timeRecord = timeRecordConcurrentHashMap.get(nettyClient.getPort());
                            timeRecord.setRequestId(request.getRequestId());
                            //请求时间记录
                            long l = System.currentTimeMillis();
                            timeRecord.setRequestTime(l);
                            timeRecord.setService(request.getClassName() + request.getMethodName());

                            postRequest(request,nettyClient.getChannel() ,timeRecord);


                        }


                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                List<Object> objects = new ArrayList<>();
                userClientHandlers.forEach(e->{
                    try {
                        Object s = executor.submit(e).get();
                        objects.add(s);
                    } catch (InterruptedException ex) {
                        ex.printStackTrace();
                    } catch (ExecutionException ex) {
                        ex.printStackTrace();
                    } finally {

                    }
                });

                    return objects.toString();

            }


        });


    }


    private NettyClient getCompareTimeResult() {
        Random random = new Random();
        int ran = random.nextInt(nettyClientHashMap.size());
        Set<Integer> set = new TreeSet<>();
        final TimeRecord timeRecord1 = new TimeRecord();

        nettyClientHashMap.entrySet().forEach(e->{

            TimeRecord timeRecord = timeRecordConcurrentHashMap.get(e.getKey());
            set.add(timeRecord.getCostTime());

            if (timeRecord1.getPort() == null || timeRecord1.getCostTime() >timeRecord.getCostTime()){
                timeRecord1.setPort(timeRecord.getPort());
                timeRecord1.setCostTime(timeRecord.getCostTime());

            }

        });

        if (set.size() == 1){  //随机
            List<Integer> collect = timeRecordConcurrentHashMap.entrySet().stream().map(e -> e.getKey()).collect(Collectors.toList());
            Integer integer = collect.get(ran);
            return nettyClientHashMap.get(integer);
        }else {
            return nettyClientHashMap.get(timeRecord1.getPort());
        }

    }


    public void listenNode() throws Exception {
        RetryPolicy retryPolicy = new ExponentialBackoffRetry(1000, 3);

        CuratorFramework curatorFramework = CuratorFrameworkFactory.builder()
                .connectString("49.234.146.31:2181")
                .sessionTimeoutMs(5000)
                .connectionTimeoutMs(2000)
                .retryPolicy(retryPolicy)
                .namespace("netty")
                .build();


        curatorFramework.start();


        this.curatorFramework = curatorFramework;

        List<String> strings = curatorFramework.getChildren().forPath("/");

        System.out.println("子节点列表"+strings);

        for (String string : strings) {

            Integer port = StringUtil.getPortFromPath(string);
            if(nettyClientHashMap.get(port) == null){
                NettyClient nettyClient = new NettyClient(null,port);
                nettyClient.initClient();

                nettyClientHashMap.put(port,nettyClient);



                //初始化存储时间的map
                TimeRecord timeRecord = new TimeRecord();
                timeRecord.setPort(port);
                timeRecordConcurrentHashMap.putIfAbsent(port,timeRecord);
            }

        }



        PathChildrenCache pathChildrenCache = new PathChildrenCache(curatorFramework, "/", true);
        pathChildrenCache.getListenable().addListener(new PathChildrenCacheListener() {
            @Override
            public void childEvent(CuratorFramework curatorFramework, PathChildrenCacheEvent pathChildrenCacheEvent) throws Exception {

                ChildData data = pathChildrenCacheEvent.getData();
                if (data != null && PathChildrenCacheEvent.Type.CHILD_ADDED.compareTo(pathChildrenCacheEvent.getType()) == 0) {

                    try {
                        String path = data.getPath();
                        System.out.println("单个子节点列表"+path);
                        String substring = path.substring(1);
                        Integer port = StringUtil.getPortFromPath(path);
                        NettyClient nettyClient = new NettyClient(null,port);
                        nettyClient.initClient();

                        nettyClientHashMap.putIfAbsent(port,nettyClient);
                    } catch (Exception e){
                        e.printStackTrace();
                    }
                }

                if (data != null && PathChildrenCacheEvent.Type.CHILD_REMOVED.compareTo(pathChildrenCacheEvent.getType()) == 0) {

                    try {
                        String substring = data.getPath().substring(1);
                        Integer port = StringUtil.getPortFromPath(substring);
                        nettyClientHashMap.remove(port);

                    }catch (Exception e){
                        e.printStackTrace();
                    }

                }
            }
        });

        pathChildrenCache.start();

    }



}
