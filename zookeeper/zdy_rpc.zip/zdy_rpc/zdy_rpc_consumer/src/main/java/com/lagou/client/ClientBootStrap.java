package com.lagou.client;

import com.lagou.service.UserService;

public class ClientBootStrap {

    public static  final String providerName="UserService#sayHello#";

    public static void main(String[] args) throws Exception {

        RpcConsumer rpcConsumer = new RpcConsumer(null);
        //初始化监听客户端
        rpcConsumer.listenNode();




        UserService proxy = (UserService) rpcConsumer.createProxy(UserService.class, providerName);

        while (true){
            Thread.sleep(3000);
            System.out.println(proxy.getData("传递参数1","传递参数2"));
        }


    }




}
