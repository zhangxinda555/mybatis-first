package com.lagou.client;

public class RouterServer {

    private static RouterServer routerServer;



    public  static RouterServer getInstance(){
        if (routerServer != null){
            return routerServer;
        }else {
            synchronized (TimeRecord.class){
                if (routerServer == null){
                    return new RouterServer();
                }
            }
        }

        return routerServer;
    }



}
