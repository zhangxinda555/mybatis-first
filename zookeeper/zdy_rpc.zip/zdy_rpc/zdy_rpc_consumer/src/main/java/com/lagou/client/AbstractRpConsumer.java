package com.lagou.client;

import com.lagou.model.RpcRequest;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.GenericFutureListener;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

public class AbstractRpConsumer {

    protected static ConcurrentHashMap<Integer, TimeRecord> timeRecordConcurrentHashMap = new ConcurrentHashMap<>();

    protected static ConcurrentHashMap<Integer, NettyClient> nettyClientHashMap = new ConcurrentHashMap<>();


    protected void postRequest(RpcRequest rpcRequest, ChannelFuture channelFuture1,TimeRecord timeRecord) {

        if (channelFuture1.awaitUninterruptibly(30000, TimeUnit.MILLISECONDS)) {

            Channel channel = channelFuture1.channel();
            if (channel != null && channel.isActive()) {

                channel.writeAndFlush(rpcRequest).addListener(new GenericFutureListener<Future<? super Void>>() {
                    @Override
                    public void operationComplete(Future<? super Void> future) throws Exception {
                        if (future.isSuccess()) {

                            System.out.println("成功发出请求");
                        } else {
                            System.out.println("我发出请求失败");
                        }
                    }
                });
            }
        }


    }


}
