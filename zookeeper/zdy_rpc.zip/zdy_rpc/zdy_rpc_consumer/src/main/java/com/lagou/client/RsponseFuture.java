package com.lagou.client;

public class RsponseFuture {

    private boolean statue;

    private UserClientHandler userClientHandler;

    public boolean isStatue() {
        return statue;
    }

    public void setStatue(boolean statue) {
        this.statue = statue;
    }

    public UserClientHandler getUserClientHandler() {
        return userClientHandler;
    }

    public void setUserClientHandler(UserClientHandler userClientHandler) {
        this.userClientHandler = userClientHandler;
    }
}
