package com.lagou.client;

public class TimeRecord {

    private String requestId;

    private Integer port;

    private String ip;

    private String service;

    private Long requestTime;

    private Long responseTime;


    private int costTime;

    private static TimeRecord timeRecord;



    public TimeRecord(){

    }




    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public Integer getPort() {
        return port;
    }

    public void setPort(Integer port) {
        this.port = port;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public Long getRequestTime() {
        return requestTime;
    }

    public void setRequestTime(Long requestTime) {
        this.requestTime = requestTime;
    }

    public Long getResponseTime() {
        return responseTime;
    }

    public void setResponseTime(Long responseTime) {
        this.responseTime = responseTime;
    }

    public int getCostTime() {
        return costTime;
    }

    public void setCostTime(int costTime) {
        this.costTime = costTime;
    }

    @Override
    public String toString() {
        return "TimeRecord{" +
                "requestId='" + requestId + '\'' +
                ", port=" + port +
                ", ip='" + ip + '\'' +
                ", service='" + service + '\'' +
                ", requestTime=" + requestTime +
                ", responseTime=" + responseTime +
                ", costTime=" + costTime +
                '}';
    }
}
