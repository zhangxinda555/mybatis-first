package com.lagou.client;

import com.lagou.model.RpcRequest;
import com.lagou.model.RpcResponse;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;

import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;

public class UserClientHandler extends ChannelInboundHandlerAdapter implements Callable {

    private ChannelHandlerContext context;
    private String result;
    private RpcRequest para;
    private CountDownLatch downLatch = new CountDownLatch(1);



    public void channelActive(ChannelHandlerContext ctx) {
        context = ctx;
    }

    /**
     * 收到服务端数据，唤醒等待线程
     */

    public  void channelRead(ChannelHandlerContext ctx, Object msg) {
        RpcResponse response = (RpcResponse) msg;
        System.out.println(response.toString()+"---------------");

        result = response.getResult().toString();
        downLatch.countDown();
        try {
            AbstractRpConsumer.timeRecordConcurrentHashMap.entrySet().forEach(e->{
                if (response.getRequestId().equals(e.getValue().getRequestId())){
                    //响应时间
                    long l = System.currentTimeMillis();

                    e.getValue().setResponseTime(l);
                    e.getValue().setCostTime((int) (e.getValue().getResponseTime()-e.getValue().getRequestTime()));
                    System.out.println("我是端口为："+e.getValue().getPort()+"的服务，我的响应时长+++++"+e.getValue().getCostTime());
                }
            });
        }catch (Exception e){
            e.printStackTrace();
        }
        //result=msg.toString();
        //notify();
    }

    /**
     * 写出数据，开始等待唤醒
     */

    public  Object call() throws InterruptedException {
        downLatch.await();
        return result;
    }

    /*
     设置参数
     */
    void setPara(RpcRequest para) {
        this.para = para;
    }



}
