package com.lagou.edu.zookeeper_web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZookeeperWebApplicationTests {

    @Test
    void contextLoads() {
    }

}
