package com.lagou.edu.mvcframework.pojo;

import java.util.List;

/**
 * 封装拦截controller 以及 method 的 url的用户权限
 */
public class Intercepter {

    private List<String> controllerSecurity;
    private List<String> methodSecurity;

    public List<String> getControllerSecurity() {
        return controllerSecurity;
    }

    public void setControllerSecurity(List<String> controllerSecurity) {
        this.controllerSecurity = controllerSecurity;
    }

    public List<String> getMethodSecurity() {
        return methodSecurity;
    }

    public void setMethodSecurity(List<String> methodSecurity) {
        this.methodSecurity = methodSecurity;
    }
}
