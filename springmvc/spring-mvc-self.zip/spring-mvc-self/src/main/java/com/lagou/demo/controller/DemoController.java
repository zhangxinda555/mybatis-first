package com.lagou.demo.controller;

import com.lagou.demo.service.IDemoService;
import com.lagou.edu.mvcframework.annotations.LagouAutowired;
import com.lagou.edu.mvcframework.annotations.LagouController;
import com.lagou.edu.mvcframework.annotations.LagouRequestMapping;
import com.lagou.edu.mvcframework.annotations.Security;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@LagouController
@LagouRequestMapping("/demo")
@Security({"zhangsan","lisi"})
public class DemoController {


    @LagouAutowired
    private IDemoService demoService;


    /**
     * URL: /demo/query?name=lisi
     * @param request
     * @param response
     * @param name
     * @return
     */
    @LagouRequestMapping("/query")
    @Security("zhangsan")
    public void query(HttpServletRequest request, HttpServletResponse response,String username) {
        response.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        demoService.get(username);

        try {
            response.getWriter().write("用户权限已通过，查询的结果为："+username);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
