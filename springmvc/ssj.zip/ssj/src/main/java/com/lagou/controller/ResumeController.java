package com.lagou.controller;


import com.lagou.pojo.Resume;
import com.lagou.service.ResumeService;
import com.lagou.service.impl.ResumeServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/resume")

public class ResumeController {

    @Autowired
    private ResumeService resumeService;


    @RequestMapping("findAll")
    public List<Resume> findResumeList(){
        List<Resume> resumeList = resumeService.findResumeList();
        return resumeList;
    }

    @RequestMapping(value = "deleteResume",method = RequestMethod.POST)
    public void deleteResumeById(Long id){
        resumeService.deleteResumeById(id);
    }

    @RequestMapping(value = "updateResume",method = RequestMethod.POST)
    public void updateResume(@RequestBody Resume resume){
        resumeService.updateResumeByModel(resume);
    }

    @RequestMapping(value = "insertResume",method = RequestMethod.POST)
    public void insertResume(@RequestBody Resume resume){
        resumeService.insertResume(resume);
    }
}
