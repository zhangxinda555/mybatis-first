package com.lagou.service.impl;


import com.lagou.dao.ResumeDao;
import com.lagou.pojo.Resume;
import com.lagou.service.ResumeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ResumeServiceImpl implements ResumeService {

    @Autowired
    private ResumeDao resumeDao;
    @Override
    public List<Resume> findResumeList() {
        List<Resume> all = resumeDao.findAll();
        return all;
    }

    @Override
    public void deleteResumeById(Long id) {

        resumeDao.deleteById(id);

    }

    @Override
    public void updateResumeByModel(Resume resume) {

        resumeDao.saveAndFlush(resume);

    }

    @Override
    public Long insertResume(Resume resume) {
        Resume save = resumeDao.save(resume);
        return save.getId();
    }
}
