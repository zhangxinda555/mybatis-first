package com.lagou.service;

import com.lagou.pojo.Resume;

import java.util.List;

public interface ResumeService {

    List<Resume> findResumeList();

    void deleteResumeById(Long id);

    void updateResumeByModel(Resume resume);

    Long insertResume(Resume resume);
}
