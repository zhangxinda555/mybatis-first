package com.lagou.controller;


import com.fasterxml.jackson.databind.util.JSONPObject;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;


@RequestMapping("/login")
@Controller
public class LogInController {


    @RequestMapping(value = "/codeLogin")
    public ModelAndView codelogin(HttpServletRequest request, HttpServletResponse response, String username, String password) throws IOException, ServletException {
        ModelAndView modelAndView = new ModelAndView();

        if (StringUtils.isAnyBlank(username,password)){
            modelAndView.addObject("message","用户名和密码不能为空");
            modelAndView.addObject("code","500");
            modelAndView.setViewName("login");

        }
        if ("admin".equals(username) && "admin".equals(password)) {
            request.getSession().setAttribute("userName",username);
            modelAndView.addObject("message","登陆成功");
            modelAndView.addObject("code","200");
            modelAndView.setViewName("list");
        }else {
            modelAndView.addObject("message","用户名和密码错误");
            modelAndView.addObject("code","500");
            modelAndView.setViewName("login");
        }

        return modelAndView;
    }

    @RequestMapping("/loginpage")
    public ModelAndView login(){
        System.out.println("123");
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("message","跳转到登陆页面");
        modelAndView.setViewName("login");
        return modelAndView;
    }



}
