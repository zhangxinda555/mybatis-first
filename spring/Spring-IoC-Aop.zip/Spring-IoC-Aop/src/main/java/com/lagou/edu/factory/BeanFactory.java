package com.lagou.edu.factory;

import com.lagou.edu.annotations.*;
import com.lagou.edu.dao.AccountDao;

import java.io.File;
import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.charset.Charset;
import java.util.*;

/**
 * @author 应癫
 * <p>
 * 工厂类，生产对象（使用反射技术）
 */
public class BeanFactory {


    private static Map<Class<?>, Object> map = new HashMap<>();  // 存储有value值的bean的value和类型
    private static Map<Class<?>, Object> mapBean = new HashMap<>();  // 存储对象和对象的类型


    static {

        try {
            String basePackage = "com.lagou.edu";
            Enumeration<URL> resources = BeanFactory.class.getClassLoader().getResources(basePackage.replace(".", "/"));
            while (resources.hasMoreElements()) {
                URL url = resources.nextElement();
                String protocol = url.getProtocol();
                if (protocol.equals("file")) {
                    String filePath = URLDecoder.decode(url.getPath(), Charset.defaultCharset());
                    File file = new File(filePath);

                    Set<String> allReferenceClassName = getAllClassName(basePackage, file, "", new HashSet<>());
                    for (String className : allReferenceClassName) {
                        //有Service、Repository、Component的注解的类才会被加载进BeanFactory

                        Class<?> classBean = Class.forName(className);
                        Service annotationService = classBean.getAnnotation(Service.class);
                        Repository annotationRepository = classBean.getAnnotation(Repository.class);
                        Component annotationComponent = classBean.getAnnotation(Component.class);
                        if (annotationService != null || annotationRepository != null || annotationComponent != null) {

                            //如果这些注解有值的话，那么增加一个值对应对象的entry
                            String value = "";
                            if (annotationService != null && annotationService.value() != "" && annotationService.value() != null) {
                                value = annotationService.value();
                            }
                            if (annotationRepository != null && annotationRepository.value() != "" && annotationRepository.value() != null) {
                                value = annotationService.value();
                            }
                            if (annotationComponent != null && annotationComponent.value() != "" && annotationComponent.value() != null) {
                                value = annotationService.value();
                            }
                            //接口不能实例化，所以这里只考虑了注解放在实现类上的情况
                            //todo
                            map.put(classBean, value);
                            Object o = classBean.newInstance();

                            mapBean.put(classBean,o);



                        }

                    }
                } else if (protocol.equals("jar")) {
                    //todo
                }

            }

            //拿到所有的bean后，可以给属性中的Autowored设置对象
            for (Class<?> classObject : map.keySet()) {
                //如果value有值的话，并且注入的注解也有值的话
                if (classObject.isInterface()) {
                    continue;
                }
                Field[] declaredFields = classObject.getDeclaredFields();
                for (Field declaredField : declaredFields) {
                    Autowired annotation = declaredField.getAnnotation(Autowired.class);

                    if (annotation != null) {

                        if (declaredField.getType().isInterface()) {
                            ServiceLoader<?> load = ServiceLoader.load(declaredField.getType());
                            System.out.println(declaredField.getType());
                            int count = 0;
                            for (Object o : load) {
                                System.out.println(o);
                                count++;
                            }


                            System.out.println(count);

                            //如果有多个实现类，那么就要看比较value值了
                            if (count > 1) {
                                for (Class<?> aClass : map.keySet()) {
                                    if (aClass.isInterface()){
                                        continue;
                                    }
                                    if (declaredField.getType().isAssignableFrom(aClass) ) {
                                        String value_class= (String) map.get(aClass);
                                        String value_field = annotation.value();
                                        if(value_class == null || value_class.trim() == "" || value_field==null ||value_field.trim() ==""){
                                            throw new RuntimeException("实现类大于两个时必须要求指定Value");
                                        }
                                        if (value_class.equals(value_field)){
                                            Object o = mapBean.get(aClass);
                                            declaredField.setAccessible(true);
                                            declaredField.set(mapBean.get(classObject), o);
                                            break;
                                        }


                                    }
                                }


                            }
                        }
                        //在map里面找到这个带有Autowired注解的属性的类型
                        for (Class<?> aClass : map.keySet()) {
                            if (declaredField.getType().isAssignableFrom(aClass)) {
                                declaredField.setAccessible(true);
                                declaredField.set(mapBean.get(classObject), mapBean.get(aClass));
                                break;

                            }
                        }

                    }
                }


            }

            //属性注入的对象后，再生成代理对象
            //获取bean的代理对象
            for (Class<?> classObject : map.keySet()) {

                Transaction annotation_transaction = classObject.getAnnotation(Transaction.class);

                if(annotation_transaction != null){
                    Object o = mapBean.get(classObject);
                    ProxyFactory poxyFactory = (ProxyFactory) mapBean.get(ProxyFactory.class);
                    Object proxyObject = poxyFactory.getProxyObject(o);
                    //此时的bean是代理对象的bean
                    mapBean.put(classObject,proxyObject);
                }
            }




        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }


    }

    private static Set<String> getAllClassName(String basePackage, File file, String packageName, HashSet<String> set) {


        if (file.isDirectory()) {
            File[] files = file.listFiles();
            for (int i = 0; i < files.length; i++) {
                String newPackageName = packageName;
                newPackageName = newPackageName.concat(".").concat(files[i].getName());

                getAllClassName(basePackage, files[i], newPackageName, set);
            }
        } else {

            String className = packageName.replace(".class", "");
            set.add(basePackage.concat(className));

        }
        return set;
    }


    //对外提供获取实例对象的接口 根据type获取
    public static Object getBean(Class<?> aClass) {
        return mapBean.get(aClass);
    }

    public static void main(String[] args) {
       BeanFactory beanFactory= new BeanFactory();
        System.out.println(mapBean);
        ServiceLoader<AccountDao> load = ServiceLoader.load(AccountDao.class);
        for (AccountDao accountDao : load) {
            System.out.println(accountDao+"12312");
        }

    }

}
