package com.lagou.edu.factory;

import com.lagou.edu.annotations.Autowired;
import com.lagou.edu.annotations.Service;
import com.lagou.edu.utils.TransactionManager;
import net.sf.cglib.proxy.Enhancer;
import net.sf.cglib.proxy.MethodInterceptor;
import net.sf.cglib.proxy.MethodProxy;

import java.lang.reflect.Method;

/**
 * @author 应癫
 *
 *
 * 代理对象工厂：生成代理对象的
 */
@Service
public class ProxyFactory {

    @Autowired
    private TransactionManager transactionManager;

    //使用cglib生成代理对象
    public  Object getProxyObject(Object object){
        System.out.println(object);

       return new Enhancer().create(object.getClass(), new MethodInterceptor() {
            @Override
            public Object intercept(Object o, Method method, Object[] objects, MethodProxy methodProxy) throws Throwable {
                Object invoke = null;
                try {
                    transactionManager.beginTransaction();
                     invoke= method.invoke(object, objects);
                    transactionManager.commit();

                }catch (Exception e){
                    e.printStackTrace();
                    transactionManager.rollback();
                    throw e;
                }
                return invoke;
            }
        });

    }


}
