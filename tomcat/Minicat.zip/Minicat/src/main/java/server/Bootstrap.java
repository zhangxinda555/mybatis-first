package server;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;

import java.io.*;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.util.*;
import java.util.concurrent.*;

/**
 * Minicat的主类
 */
public class Bootstrap {

    /**
     * 定义socket监听的端口号
     */
    private int port = 8080;

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }


    /**
     * Minicat启动需要初始化展开的一些操作
     */
    public void start() throws Exception {

        // 加载解析相关的配置，web.xml
        loadServlet();

        loadClass();
        // 定义一个线程池
        int corePoolSize = 10;
        int maximumPoolSize = 50;
        long keepAliveTime = 100L;
        TimeUnit unit = TimeUnit.SECONDS;
        BlockingQueue<Runnable> workQueue = new ArrayBlockingQueue<>(50);
        ThreadFactory threadFactory = Executors.defaultThreadFactory();
        RejectedExecutionHandler handler = new ThreadPoolExecutor.AbortPolicy();


        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(
                corePoolSize,
                maximumPoolSize,
                keepAliveTime,
                unit,
                workQueue,
                threadFactory,
                handler
        );





        /*
            完成Minicat 1.0版本
            需求：浏览器请求http://localhost:8080,返回一个固定的字符串到页面"Hello Minicat!"
         */
        ServerSocket serverSocket = new ServerSocket(port);
        System.out.println("=====>>>Minicat start on port：" + port);

        /*while(true) {
            Socket socket = serverSocket.accept();
            // 有了socket，接收到请求，获取输出流
            OutputStream outputStream = socket.getOutputStream();
            String data = "Hello Minicat!";
            String responseText = HttpProtocolUtil.getHttpHeader200(data.getBytes().length) + data;
            outputStream.write(responseText.getBytes());
            socket.close();
        }*/


        /**
         * 完成Minicat 2.0版本
         * 需求：封装Request和Response对象，返回html静态资源文件
         */
        /*while(true) {
            Socket socket = serverSocket.accept();
            InputStream inputStream = socket.getInputStream();

            // 封装Request对象和Response对象
            Request request = new Request(inputStream);
            Response response = new Response(socket.getOutputStream());

            response.outputHtml(request.getUrl());
            socket.close();

        }*/


        /**
         * 完成Minicat 3.0版本
         * 需求：可以请求动态资源（Servlet）
         */
        /*while(true) {
            Socket socket = serverSocket.accept();
            InputStream inputStream = socket.getInputStream();

            // 封装Request对象和Response对象
            Request request = new Request(inputStream);
            Response response = new Response(socket.getOutputStream());

            // 静态资源处理
            if(servletMap.get(request.getUrl()) == null) {
                response.outputHtml(request.getUrl());
            }else{
                // 动态资源servlet请求
                HttpServlet httpServlet = servletMap.get(request.getUrl());
                httpServlet.service(request,response);
            }

            socket.close();

        }
*/

        /*
            多线程改造（不使用线程池）
         */
        /*while(true) {
            Socket socket = serverSocket.accept();
            RequestProcessor requestProcessor = new RequestProcessor(socket,servletMap);
            requestProcessor.start();
        }*/


        System.out.println("=========>>>>>>使用线程池进行多线程改造");
        /*
            多线程改造（使用线程池）
         */
        while (true) {

            Socket socket = serverSocket.accept();
            RequestProcessor requestProcessor = new RequestProcessor(socket, servletMap);
            //requestProcessor.start();
            threadPoolExecutor.execute(requestProcessor);
        }


    }


    private Map<String, HttpServlet> servletMap = new HashMap<String, HttpServlet>();
    private String appBase;
    private List<String> packageNames = new ArrayList<>();

    /**
     * 加载解析web.xml，初始化Servlet
     */
    private void loadServlet() {
        InputStream resourceAsStream = this.getClass().getClassLoader().getResourceAsStream("server.xml");
        loadXmlFile(resourceAsStream);

    }

    private Map<String, String> pattenServletName = new HashMap<String, String>();

    public void loadClass() {

        File file = new File(appBase);
        if (file.isDirectory() ) {
            File[] files = file.listFiles();
            for (int j = 0; j < files.length; j++) {
                if (files[j].isDirectory() && packageNames.contains("/"+ files[j].getName())) {
                    File[] files1 = files[j].listFiles();
                    for (int i1 = 0; i1 < files1.length; i1++) {
                        if ("web.xml".equals(files1[i1].getName())) {
                            SAXReader saxReader = new SAXReader();
                            FileInputStream fileInputStream = null;
                            try {
                                fileInputStream = new FileInputStream(files1[i1]);
                            } catch (FileNotFoundException e) {
                                e.printStackTrace();
                            }
                            try {
                                Document document = saxReader.read(fileInputStream);
                                Element rootElement = document.getRootElement();

                                List<Element> selectNodes = rootElement.selectNodes("//servlet");
                                for (int i = 0; i < selectNodes.size(); i++) {
                                    Element element = selectNodes.get(i);
                                    // <servlet-name>lagou</servlet-name>
                                    Element servletnameElement = (Element) element.selectSingleNode("servlet-name");
                                    String servletName = servletnameElement.getStringValue();
                                    // <servlet-class>server.LagouServlet</servlet-class>
                                    Element servletclassElement = (Element) element.selectSingleNode("servlet-class");
                                    String servletClass = servletclassElement.getStringValue();
                                    // 根据servlet-name的值找到url-pattern
                                    Element servletMapping = (Element) rootElement.selectSingleNode("/web-app/servlet-mapping[servlet-name='" + servletName + "']");
                                    // /lagou
                                    String urlPattern = servletMapping.selectSingleNode("url-pattern").getStringValue();
                                    pattenServletName.put(urlPattern, servletClass);
                                }

                            } catch (DocumentException e) {
                                e.printStackTrace();
                            }

                        }


                    }



                }
            }
        }

        //读取xml后将配置的类实例化放入map中
        for (String pattern : pattenServletName.keySet()) {
            String className = pattenServletName.get(pattern);
            MyClassLoader myClassLoader = new MyClassLoader(appBase + pattern +"/" + className.replace(".", "/") + ".class");
            Class<?> aClass = null;
            try {
                aClass = myClassLoader.findClass(className);
                Constructor<?> declaredConstructor = aClass.getDeclaredConstructor();
                declaredConstructor.setAccessible(true);
                Object o = declaredConstructor.newInstance();
                servletMap.put(pattern, (HttpServlet) o);

            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (InstantiationException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
            System.out.println(aClass);
        }


    }

    private void loadXmlFile(InputStream fileInputStream) {
        SAXReader saxReader = new SAXReader();

        try {
            Document document = saxReader.read(fileInputStream);
            Element rootElement = document.getRootElement();

            Element selectSingleNode = (Element) rootElement.selectSingleNode("//Host");
            appBase = selectSingleNode.attributeValue("appBase");
            List<Element> selectNodes = selectSingleNode.selectNodes("Context");
            for (Element selectNode : selectNodes) {
                String aPackage = selectNode.attributeValue("package");
                packageNames.add(aPackage);
            }


        } catch (DocumentException e) {
            e.printStackTrace();
        }
    }


    /**
     * Minicat 的程序启动入口
     *
     * @param args
     */
    public static void main(String[] args) {
        Bootstrap bootstrap = new Bootstrap();
        try {

            System.out.println(bootstrap.servletMap);

            // 启动Minicat
            bootstrap.start();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
