package server;

import java.io.*;

public class MyClassLoader extends ClassLoader {

    protected String location;
    public MyClassLoader(String location){
        this.location = location;
    }
    @Override
    protected Class<?> findClass(String name) throws ClassNotFoundException {
        byte[] bytes = getDataByte(name);
        return super.defineClass(name, bytes,0,bytes.length);

    }

    private byte[] getDataByte(String name) {

        File file = new File(location);
        ByteArrayOutputStream byteArrayOutputStream = null;
        try {
            FileInputStream fileInputStream = new FileInputStream(file);
            byteArrayOutputStream = new ByteArrayOutputStream();
            byte[] bytes = new byte[1024];
            int len = 0;
            while ((len = fileInputStream.read(bytes,0,bytes.length))>-1){

                byteArrayOutputStream.write(bytes,0,len);
                System.out.println("正在读取数据。。。");
            }
            fileInputStream.close();

            return byteArrayOutputStream.toByteArray();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                byteArrayOutputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return new byte[0];
    }

    public static void main(String[] args) {
        MyClassLoader classLoader = new MyClassLoader("D:/作业杂项/webapp/demo1/server/MyDemo1Servlet.class");
        Class<?> aClass = null;
        try {
            aClass = classLoader.findClass("server.MyDemo1Servlet");
            Object o = aClass.newInstance();
            System.out.println(o);

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        }
        System.out.println(aClass);
    }
}
