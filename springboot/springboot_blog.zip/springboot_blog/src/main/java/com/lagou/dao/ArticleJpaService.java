package com.lagou.dao;

import com.lagou.model.Article;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ArticleJpaService extends JpaRepository<Article,Integer> {


}
