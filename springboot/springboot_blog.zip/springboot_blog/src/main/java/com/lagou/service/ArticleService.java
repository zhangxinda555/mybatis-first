package com.lagou.service;

import com.lagou.model.Article;
import org.springframework.data.domain.Page;

import java.text.ParseException;


public interface ArticleService {

    Page<Article> findArticlePage(Integer pageSize,Integer pageNumber) throws ParseException;
}
