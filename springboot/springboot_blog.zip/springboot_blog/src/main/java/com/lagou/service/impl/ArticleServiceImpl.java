package com.lagou.service.impl;

import com.lagou.dao.ArticleJpaService;
import com.lagou.model.Article;

import com.lagou.service.ArticleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


@Service
public class ArticleServiceImpl implements ArticleService {

    @Autowired
    private ArticleJpaService articleJpaService;

    @Autowired
    private RedisTemplate redisTemplate;
    @Override
    public Page<Article> findArticlePage(Integer pageSize,Integer pageNumber) {
        Object o = redisTemplate.opsForValue().get("article_" + pageNumber);
        if (o != null) return (Page<Article>) o;
        Pageable pageable = PageRequest.of(pageNumber,pageSize);
        Page<Article> all = articleJpaService.findAll(pageable);
        for (Article article : all.getContent()) {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
            String format = simpleDateFormat.format(article.getCreated());
            try {
                article.setCreated(simpleDateFormat.parse(format));
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        redisTemplate.opsForValue().set("article_" + pageNumber,all);
        return all;
    }
}
