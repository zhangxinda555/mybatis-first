package com.lagou.model;

import java.util.List;

public class Page<T> {

    private Integer pageNumber;
    private Integer pageSize;
    private List<T> data;
    private Integer totalPage;
    private Integer count;


    public Integer getTotalPage() {
        if (pageSize == 0) return  0;
        return count%pageSize == 0 ? count/pageSize : count/pageSize + 1;
    }

    public Integer getPageNumber() {
        return pageNumber;
    }

    public void setPageNumber(Integer pageNumber) {
        this.pageNumber = pageNumber;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public List<T> getData() {
        return data;
    }

    public void setData(List<T> data) {
        this.data = data;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }
}
