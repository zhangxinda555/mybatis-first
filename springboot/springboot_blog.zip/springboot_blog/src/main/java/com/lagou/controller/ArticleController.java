package com.lagou.controller;


import com.lagou.model.Article;

import org.springframework.data.domain.Page;
import com.lagou.service.ArticleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;

@Controller
public class ArticleController {

    @Autowired
    private ArticleService articleService;


    @RequestMapping("/indexPage")
    public String indexPage(Model model,Integer pageSize,Integer pageNumber) throws ParseException {
        if (pageNumber == null ||  pageNumber<0) pageNumber =0;
        if (pageSize == null) pageSize = 3;
        Page<Article> articlePage = articleService.findArticlePage(pageSize, pageNumber);
        model.addAttribute("dataPage",articlePage);
        model.addAttribute("date", new Date());
        return "index";

    }

}
