package com.lagou.springboot_blog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootBlogApplicationTests {

    @Test
    void contextLoads() {
    }

}
