package com.lagou.config;

import com.lagou.io.Resources;
import com.lagou.mapping.MappedStatement;
import com.lagou.session.Configuration;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

public class XmlMapperBuilder {

    public static Configuration parseMapper(String mapperPath,Configuration configuration) throws DocumentException {

        InputStream resourceAsStream = Resources.getResourceAsStream(mapperPath);
        SAXReader saxReader = new SAXReader();
        Document document = saxReader.read(resourceAsStream);
        Element rootElement = document.getRootElement();
        String namespace = rootElement.attributeValue("namespace");
        Map<String, MappedStatement> mappedStatementMap = configuration.getMappedStatement();
        List<Element> selectNodes = rootElement.elements("select");
        for (Element selectNode : selectNodes) {
            String id = selectNode.attributeValue("id");
            String parameterType = selectNode.attributeValue("parameterType");
            String resultType = selectNode.attributeValue("resultType");
            String textTrim = selectNode.getTextTrim();
            MappedStatement mappedStatement = new MappedStatement();
            mappedStatement.setId(id);
            mappedStatement.setNameSpace(namespace);
            mappedStatement.setResultType(resultType);
            mappedStatement.setParameterType(parameterType);
            mappedStatement.setText(textTrim);
            mappedStatementMap.put(namespace.concat(".").concat(id),mappedStatement);
        }
        return configuration;

    }
}
