package com.lagou.session;

import com.lagou.mapping.MappedStatement;

import java.lang.reflect.*;
import java.util.List;

public class DefaultSqlSession implements SqlSession {

    private Configuration configuration;
    private Executor executor;

    public DefaultSqlSession(Configuration configuration){
        this.configuration = configuration;
        executor = new DefaultExecutor();
    }

    @Override
    public <E> List<E> selectList(String statementId, Object params) throws Exception {
        List<Object> query = executor.query(configuration, statementId, params);
        return (List<E>) query;
    }

    @Override
    public <E> E selectOne(String statementId, Object params) throws Exception {
        List<Object> objects = selectList(statementId, params);
        if (objects.size() == 1){
            return (E) objects.get(0);
        }else {
            throw new RuntimeException("要查询的结果不止一条");
        }
    }

    @Override
    public void add(String statementId, Object params) {
        executor.insert(configuration, statementId, params);
    }

    @Override
    public void update(String statementId, Object params) {
        executor.update(configuration, statementId, params);
    }

    @Override
    public void delete(String statementId, Object params) {
        executor.delete(configuration, statementId, params);
    }

    @Override
    public <E> E getMapper(Class<?> aClass) {

        Object o = Proxy.newProxyInstance(aClass.getClassLoader(), new Class[]{aClass}, new InvocationHandler() {
            @Override
            public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                String name = aClass.getName();
                String statementId = name + '.' + method.getName();
                //判断sql是select还是insert、update、delete
                MappedStatement mappedStatement = configuration.getMappedStatement().get(statementId);
                String sql = mappedStatement.getText();
                if (sql.toLowerCase().contains("insert")){
                    add(statementId,args);

                }else if (sql.toLowerCase().contains("update")){
                    update(statementId,args);

                }else if (sql.toLowerCase().contains("delete")){
                    delete(statementId,args);

                }else {
                    Type genericReturnType = method.getGenericReturnType();
                    if (genericReturnType instanceof ParameterizedType){
                        List<Object> objects = selectList(statementId, args);
                        return objects;
                    }else {
                        Object o1 = selectOne(statementId, args);
                        return o1;
                    }
                }
                return null;

            }
        });
        return (E) o;
    }
}
