package com.lagou;

import com.lagou.dao.UserMapper;
import com.lagou.model.User;
import com.lagou.session.SqlSession;
import com.lagou.session.SqlSessionFactory;
import com.lagou.session.SqlSessionFactoryBuilder;

import java.io.InputStream;
import java.util.List;

public class Test {


    @org.junit.Test
    public void test() throws Exception {

        InputStream resourceAsStream = this.getClass().getClassLoader().getResourceAsStream("sqlConfig.xml");
        SqlSessionFactory build = new SqlSessionFactoryBuilder().build(resourceAsStream);
        SqlSession sqlSession = build.openSqlSession();
        List<User> objects = sqlSession.selectList("com.lagou.dao.UserMapper.findAll", null);

        for (User object : objects) {
            System.out.println(object);
        }



    }

    @org.junit.Test
    public void test1() throws Exception {

        InputStream resourceAsStream = this.getClass().getClassLoader().getResourceAsStream("sqlConfig.xml");
        SqlSessionFactory build = new SqlSessionFactoryBuilder().build(resourceAsStream);
        SqlSession sqlSession = build.openSqlSession();
        User user = new User();
        user.setId(1);
        user.setUserName("zhangsan");
        List<User> objects = sqlSession.selectList("com.lagou.dao.UserMapper.findById", user);

        for (User object : objects) {
            System.out.println(object);
        }



    }

    @org.junit.Test
    public void test3() throws Exception {

        InputStream resourceAsStream = this.getClass().getClassLoader().getResourceAsStream("sqlConfig.xml");
        SqlSessionFactory build = new SqlSessionFactoryBuilder().build(resourceAsStream);
        SqlSession sqlSession = build.openSqlSession();
        User user = new User();
        user.setId(6);
        user.setUserName("xueren1231");
        UserMapper mapper = sqlSession.getMapper(UserMapper.class);
         //mapper.deleteUser(user);
        //mapper.addUser(user);
        //mapper.updateUser(user);
        //User byId = mapper.findById(user);
        List<User> all = mapper.findAll();
        for (User user1 : all) {
            System.out.println(user1);
        }





    }


}
