package com.lagou.sql;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BoundSql {

    private String sql;
    private List<String> names = new ArrayList<>();
    private Map<String,Object> mapping = new HashMap<>();

    public String getSql() {
        return sql;
    }

    public void setSql(String sql) {
        this.sql = sql;
    }

    public List<String> getNames() {
        return names;
    }

    public void setNames(List<String> names) {
        this.names = names;
    }

    public Map<String, Object> getMapping() {
        return mapping;
    }

    public void setMapping(Map<String, Object> mapping) {
        this.mapping = mapping;
    }

    public String getFinalSql(String text, Object parameters) throws IllegalAccessException {

        if (parameters == null ){
            return text;
        }
        Class<?> aClass = parameters.getClass();
        if (aClass.isArray()){
            Object[] objects = (Object[]) parameters;
            for (int i = 0; i < objects.length; i++) {
                text = findFinalSql(objects[i].getClass(),text,objects[i]);
            }
        }else {
            text=findFinalSql(aClass,text,parameters);
        }

        this.sql = text;
        return  text;
    }

    private String findFinalSql(Class<?> aClass,String text,Object parameters) throws IllegalAccessException {
        Field[] declaredFields = aClass.getDeclaredFields();
        for (int i = 0; i < declaredFields.length; i++) {
            declaredFields[i].setAccessible(true);
            String name = declaredFields[i].getName();
            Object value = declaredFields[i].get(parameters);

            //将带有#{字段}的替换成？
            String field = "#{" + name +"}";
            if (text.contains(field)){
                text = text.replace(field, "?");
                this.mapping.put(name,  value);
                this.names.add(name);

            }

        }
        return text;
    }
}
