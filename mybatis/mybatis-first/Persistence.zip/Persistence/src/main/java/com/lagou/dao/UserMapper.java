package com.lagou.dao;

import com.lagou.model.User;

import java.util.List;

public interface UserMapper {

    List<User> findAll();

    User findById(User user);

    void addUser(User user);

    void updateUser(User user);


    void deleteUser(User user);
}
