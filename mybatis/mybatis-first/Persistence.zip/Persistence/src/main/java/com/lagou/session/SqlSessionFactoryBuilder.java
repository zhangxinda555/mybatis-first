package com.lagou.session;

import com.lagou.config.XmlConfigBuilder;
import org.dom4j.DocumentException;

import java.beans.PropertyVetoException;
import java.io.InputStream;

public class SqlSessionFactoryBuilder {

    public static SqlSessionFactory build(InputStream inputStream) throws PropertyVetoException, DocumentException {

        XmlConfigBuilder xmlConfigBuilder = new XmlConfigBuilder();
        Configuration configuration = new Configuration();
        Configuration parseConfiguration = xmlConfigBuilder.parse(configuration, inputStream);
        return new DefaultSqlSessionFactory(parseConfiguration);

    }
}
