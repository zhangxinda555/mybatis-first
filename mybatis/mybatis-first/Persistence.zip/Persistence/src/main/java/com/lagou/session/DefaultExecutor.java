package com.lagou.session;

import com.lagou.mapping.MappedStatement;
import com.lagou.sql.BoundSql;

import javax.sql.DataSource;
import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DefaultExecutor implements  Executor {


    @Override
    public <T> List<T> query(Configuration configuration,String statementId, Object parameters) {
        MappedStatement mappedStatement = configuration.getMappedStatement().get(statementId);
        DataSource dataSource = configuration.getDataSource();
        try {
            List<T> list  = execute(mappedStatement,dataSource.getConnection(),parameters);
            return list;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public void update(Configuration configuration,String statementId, Object parameters) {
        MappedStatement mappedStatement = configuration.getMappedStatement().get(statementId);
        DataSource dataSource = configuration.getDataSource();
        try {
            updateExecute(mappedStatement,dataSource.getConnection(),parameters);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void insert(Configuration configuration,String statementId, Object parameters) {
        MappedStatement mappedStatement = configuration.getMappedStatement().get(statementId);
        DataSource dataSource = configuration.getDataSource();
        try {
            updateExecute(mappedStatement,dataSource.getConnection(),parameters);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void updateExecute(MappedStatement mappedStatement, Connection connection, Object parameters) throws SQLException, IllegalAccessException, ClassNotFoundException, NoSuchFieldException {
        PreparedStatement preparedStatement =getPreparedStatement(mappedStatement,connection,parameters);
        preparedStatement.executeUpdate();
    }

    private PreparedStatement getPreparedStatement(MappedStatement mappedStatement, Connection connection, Object parameters) throws SQLException, IllegalAccessException, ClassNotFoundException, NoSuchFieldException {
        BoundSql boundSql = new BoundSql();
        String finalSql = boundSql.getFinalSql(mappedStatement.getText(), parameters);
        PreparedStatement preparedStatement = connection.prepareStatement(finalSql);
        if (parameters != null){
            String parameterType = mappedStatement.getParameterType();
            Class<?> aClass = Class.forName(parameterType);
            Object[] objects ;
            if(!parameters.getClass().isArray()){
                objects= new Object[]{parameters};
            }else {
                objects = (Object[]) parameters;
            }

            for (int j = 0; j < objects.length; j++) {
                for (int i = 0; i < boundSql.getNames().size(); i++) {
                    String name = boundSql.getNames().get(i);
                    Field declaredField = aClass.getDeclaredField(name);
                    declaredField.setAccessible(true);
                    Object o = declaredField.get(objects[j]);
                    //参数的的位置确定
                    preparedStatementSetObject(name,o,finalSql,preparedStatement);

                }
            }


        }
        return preparedStatement;
    }

    @Override
    public void delete(Configuration configuration,String statementId, Object parameters) {
        MappedStatement mappedStatement = configuration.getMappedStatement().get(statementId);
        DataSource dataSource = configuration.getDataSource();


        try {
            updateExecute(mappedStatement,dataSource.getConnection(),parameters);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private <T> List<T> execute(MappedStatement mappedStatement,Connection connection,Object parameters) throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException, NoSuchFieldException, IntrospectionException, InvocationTargetException {

        PreparedStatement preparedStatement =getPreparedStatement(mappedStatement,connection,parameters);

        ResultSet resultSet = preparedStatement.executeQuery();
        Class<?> resultType = Class.forName(mappedStatement.getResultType());
        ArrayList<T> results = new ArrayList<T>();
        while (resultSet.next()){
            ResultSetMetaData metaData = resultSet.getMetaData();
            T o = (T) resultType.newInstance();
            int columnCount = metaData.getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                String columnName = metaData.getColumnName(i);
                Object value = resultSet.getObject(columnName);
                PropertyDescriptor propertyDescriptor = new PropertyDescriptor(columnName, resultType);
                Method writeMethod = propertyDescriptor.getWriteMethod();
                writeMethod.invoke(o,value);

            }
            results.add(o);

        }
        return results;
    }

    private void preparedStatementSetObject(String name, Object o, String finalSql, PreparedStatement preparedStatement) throws SQLException {

        int i = finalSql.indexOf(name);
        if (i<0){
            return;
        }
        String substring = finalSql.substring(0,i);
        int count = 1;
        int start = 0;
        //insert特殊
        if (finalSql.toLowerCase().contains("insert")){
            while (true){

                int i1 = substring.indexOf(",",start);
                if (i1 >= 0){
                    count++;
                    start = i1 + 1;
                }else {
                    break;
                }
            }
        }else {
            while (true){

                int i1 = substring.indexOf("?",start);
                if (i1 >= 0){
                    count++;
                    start = i1 + 1;
                }else {
                    break;
                }
            }
        }
        preparedStatement.setObject(count,o);
    }


}
