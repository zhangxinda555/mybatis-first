package com.lagou.session;

import java.util.List;

public interface SqlSession {

     <E> List<E> selectList(String statementId, Object params) throws Exception;

     <E> E selectOne(String statementId, Object params) throws Exception;

     void add(String statementId, Object params);

     void update(String statementId, Object params);

     void delete(String statementId, Object params);

     <E> E getMapper(Class<?> aClass);
}
