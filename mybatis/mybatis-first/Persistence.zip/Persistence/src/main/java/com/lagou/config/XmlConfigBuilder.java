package com.lagou.config;

import com.lagou.session.Configuration;
import com.mchange.v2.c3p0.ComboPooledDataSource;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;


import java.beans.PropertyVetoException;
import java.io.InputStream;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class XmlConfigBuilder {



    public  Configuration parse(Configuration configuration,InputStream inputStream) throws DocumentException, PropertyVetoException {
        Document read = new SAXReader().read(inputStream);
        Element rootElement = read.getRootElement();
        //获取sqlconfig.xml
        Map<String,String> propertyMap = new HashMap<>();
        List<Element> propertyElement = (List<Element>) rootElement.elements("property");
        for (Element element1 : propertyElement) {
            String name = element1.attributeValue("name");
            String value = element1.attributeValue("value");
            propertyMap.put(name,value);


        }

        ComboPooledDataSource comboPooledDataSource = new ComboPooledDataSource();
        comboPooledDataSource.setUser(propertyMap.get("username"));
        comboPooledDataSource.setPassword(propertyMap.get("password"));
        comboPooledDataSource.setDriverClass(propertyMap.get("driver"));
        comboPooledDataSource.setJdbcUrl(propertyMap.get("url"));

        //数据源
        configuration.setDataSource(comboPooledDataSource);

        //获取Mapper.xml

        Element mappers = rootElement.element("mappers");

        List<Element> mapperList = mappers.elements("mapper");
        for (Element mapper : mapperList) {
            String resource = mapper.attributeValue("resource");
             configuration = XmlMapperBuilder.parseMapper(resource, configuration);
        }
        return configuration;
    }
}
