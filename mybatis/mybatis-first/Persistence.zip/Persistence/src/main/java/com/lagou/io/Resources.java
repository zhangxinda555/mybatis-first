package com.lagou.io;

import java.io.InputStream;

public class Resources {

    public static InputStream getResourceAsStream(String path){
        if (path == null || path.trim() =="" ){
            throw new RuntimeException("路径不能为空");
        }
        InputStream resourceAsStream = Resources.class.getClassLoader().getResourceAsStream(path);
        return resourceAsStream;
    }
}
