package com.lagou.session;

public interface SqlSessionFactory {

    SqlSession openSqlSession();
}
