package com.lagou.session;

import com.lagou.mapping.MappedStatement;
import com.lagou.sql.BoundSql;

import java.util.List;

public interface Executor {

    <T> List<T> query(Configuration configuration,String statementId, Object parameters);
    void insert(Configuration configuration,String statementId, Object parameters);
    void update(Configuration configuration,String statementId, Object parameters);
    void delete(Configuration configuration,String statementId, Object parameters);
}
