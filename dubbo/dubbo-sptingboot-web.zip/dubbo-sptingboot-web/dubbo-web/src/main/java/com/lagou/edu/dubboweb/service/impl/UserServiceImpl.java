package com.lagou.edu.dubboweb.service.impl;

import com.alibaba.dubbo.config.annotation.Service;
import com.lagou.edu.dubboweb.service.UserService;
import org.springframework.stereotype.Component;


//@Service
//@Component
public class UserServiceImpl implements UserService {
    @Override
    public String sayHello(String name) {
        return name + ":你好!";
    }

    @Override
    public void tansportIpone() {

    }

    @Override
    public void tansportIptwo() {

    }
}
