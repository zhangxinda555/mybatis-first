package com.lagou.edu.dubboweb.service;

public interface UserService {

    String sayHello(String name);

    void tansportIpone();
    void tansportIptwo();
}
