package com.lagou.edu.dubboweb.controller;


import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.dubbo.rpc.RpcContext;
import com.lagou.edu.dubboweb.service.UserService;
import com.lagou.edu.dubboweb.service.UserTwoService;
import com.lagou.edu.dubboweb.util.MyLocalThreadLocal;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping(value = "/invoke")
public class InvokerController {

    @Reference
    private UserService userService;

    @Reference
    private UserTwoService usertwoService;


    @RequestMapping(method = RequestMethod.GET,value = "/transportIp")
    public void transportIp(HttpServletRequest request){
        String remoteHost = request.getRemoteHost();
        MyLocalThreadLocal.getInstance().set(remoteHost);
        //RpcContext.getContext().setAttachment("ip",remoteHost);
        userService.tansportIpone();
        usertwoService.tansportIptwo();
    }
}
