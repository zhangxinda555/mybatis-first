package com.lagou.edu.dubboweb.service;

public interface UserTwoService {
    public void tansportIptwo();
}
