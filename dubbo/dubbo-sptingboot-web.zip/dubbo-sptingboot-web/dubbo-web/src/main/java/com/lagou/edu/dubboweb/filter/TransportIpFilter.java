package com.lagou.edu.dubboweb.filter;


import com.alibaba.dubbo.common.Constants;
import com.alibaba.dubbo.common.extension.Activate;
import com.alibaba.dubbo.common.extension.Adaptive;
import com.alibaba.dubbo.common.extension.SPI;
import com.alibaba.dubbo.rpc.Filter;
import com.alibaba.dubbo.rpc.Invocation;
import com.alibaba.dubbo.rpc.Invoker;
import com.alibaba.dubbo.rpc.Result;
import com.alibaba.dubbo.rpc.RpcContext;
import com.alibaba.dubbo.rpc.RpcException;
import com.lagou.edu.dubboweb.util.MyLocalThreadLocal;

import java.util.Map;
@Activate(group = Constants.CONSUMER)
public class TransportIpFilter implements Filter {

    @Override
    public Result invoke(Invoker <?> invoker, Invocation invocation) throws RpcException {
        String Ip = (String) MyLocalThreadLocal.getInstance().get();
        RpcContext.getContext().setAttachment("ip",Ip);
        Result invoke = invoker.invoke(invocation);
        return invoke;
    }
}
