package com.lagou.edu.dubboweb.util;

public class MyLocalThreadLocal {

    private final static ThreadLocal threadLocal = new ThreadLocal();

    public static ThreadLocal getInstance(){
        return threadLocal;
    }
}
