package com.lagou.edu.dubboweb.service.impl;

import com.alibaba.dubbo.config.annotation.Reference;
import com.lagou.edu.dubboweb.service.InvokeService;
import org.springframework.stereotype.Service;

@Service
public class InvokeServiceImpl {



}
