package com.lagou.edu.dubboweb.service;

public interface InvokeService {

    String active(String name);
}
