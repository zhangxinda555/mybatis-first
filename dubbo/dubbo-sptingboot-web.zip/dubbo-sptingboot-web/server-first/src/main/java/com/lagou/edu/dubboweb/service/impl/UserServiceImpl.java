package com.lagou.edu.dubboweb.service.impl;

import com.alibaba.dubbo.config.annotation.Service;
import com.alibaba.dubbo.rpc.RpcContext;
import com.lagou.edu.dubboweb.service.UserService;
import org.springframework.stereotype.Component;


import java.util.Map;


@Component
@Service
public class UserServiceImpl implements UserService {
    @Override
    public String sayHello(String name) {
        return null;
    }

    @Override
    public void tansportIpone() {
        Map <String, String> attachments = RpcContext.getContext().getAttachments();
        String s = attachments.get("ip");
        System.out.println(s);
    }
}
