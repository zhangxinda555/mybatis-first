package com.lagou.edu.dubboweb.controller;


import com.lagou.edu.dubboweb.service.InvokeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/user")
public class InvokeController  {

    @Autowired
    private InvokeService invokeService;


    @RequestMapping(method = RequestMethod.POST,value = "/sayHello")
    public String sayHello(String name){
        return invokeService.active(name);
    }
}
