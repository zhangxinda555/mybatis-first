package com.lagou.edu.dubboweb.service.impl;

import com.alibaba.dubbo.config.annotation.Reference;
import com.lagou.edu.dubboweb.service.InvokeService;
import com.lagou.edu.dubboweb.service.UserService;
import org.springframework.stereotype.Service;

@Service
public class InvokeServiceImpl implements InvokeService {


    @Reference
    private UserService userService;
    @Override
    public String active(String name) {

        return userService.sayHello(name);
    }
}
