package com.lagou.edu.dubboweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerFirstApplicationTests {

    @Test
    void contextLoads() {
    }

}
