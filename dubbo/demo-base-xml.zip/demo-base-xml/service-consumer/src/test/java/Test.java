import com.lagou.MethodInfo;
import com.lagou.MethodStatasticsUtil;
import sun.awt.ModalExclude;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

public class Test {

    public static void main(String[] args) {

        //MethodStatasticsUtil methodStatasticsUtil = new MethodStatasticsUtil();

        Random random = new Random(1000);




        for (int i = 0; i < 200; i++) {
            List<MethodInfo> methodInfos = new ArrayList <>();
            for (int j = 0; j < 1000; j++) {
                long currentTimeMillis = System.currentTimeMillis();
                MethodInfo methodInfo = new MethodInfo();
                methodInfo.setTime(currentTimeMillis);
                methodInfos.add(methodInfo);
            }

            long currentTimeMillis1 = System.currentTimeMillis();
            List <MethodInfo> collect = methodInfos.stream().sorted(Comparator.comparing(o -> o.getTime())).collect(Collectors.toList());
            System.out.println("时间花了:"+(System.currentTimeMillis() - currentTimeMillis1) +"   list大小为:"+collect.size());


        }


    }
}
