package com.lagou;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

public class MethodStatasticsUtil implements Runnable{

    public static  Map<String, List <MethodInfo>> methods = new HashMap <>();



    public MethodStatasticsUtil() {
        Executors.newScheduledThreadPool(1).scheduleAtFixedRate(this, 5,5, TimeUnit.SECONDS);

    }


    @Override
    public void run() {

        long currentTimeMillis = System.currentTimeMillis();
        long oneMinute = currentTimeMillis - 60 * 1000;
        Map <String, List <MethodInfo>> hashMap = new HashMap <>();
        hashMap.putAll(methods);
        hashMap.entrySet().forEach(e->{

            String key = e.getKey();
            List <MethodInfo> methodInfoss = e.getValue();
            //List<MethodInfo> methodInfos = new ArrayList <>(value);
            System.out.println("方法"+key+"的List大小为:"+methodInfoss.size());
            List<MethodInfo> removeList = new ArrayList <>();
            /*Collections.sort(methodInfos, new Comparator <MethodInfo>() {
                @Override
                public int compare(MethodInfo o1, MethodInfo o2) {
                    return o1.getTime().compareTo(o2.getTime());
                }(e1, e2) -> e1.getTime().compareTo(e2.getTime())
            });*/
            List <MethodInfo> methodInfos = methodInfoss.stream().sorted(Comparator.comparing(o->o.getTime().intValue())).collect(Collectors.toList());
            long currentTimeMillis2 = System.currentTimeMillis();
            System.out.println("==========="+(currentTimeMillis2-currentTimeMillis) );
            //System.out.println(methodInfos);
            int tp90 = (int) (methodInfos.size() * 0.9);
            int tp99 = (int) (methodInfos.size() * 0.99);
            MethodInfo methodInfo_90 = methodInfos.get(tp90);
            MethodInfo methodInfo_99 = methodInfos.get(tp99);
            System.out.println("方法"+key+"的TP90耗时为:"+methodInfo_90.getTime());
            System.out.println("方法"+key+"的TP99耗时为:"+methodInfo_99.getTime());
            System.out.println();
            methodInfos.stream().forEach(methodInfo->{
                if (methodInfo.getCurrentDateTime()<oneMinute) removeList.add(methodInfo);
            });
            methods.get(key).removeAll(removeList);
        });

        long currentTimeMillis1 = System.currentTimeMillis();

        System.out.println("==========="+(currentTimeMillis1-currentTimeMillis) );

    }


}
