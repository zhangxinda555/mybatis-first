package com.lagou;

import com.lagou.service.HelloService;
import com.sun.deploy.nativesandbox.NativeSandboxBroker;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.Random;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ConsumerApplication {
    private static ExecutorService executorService = Executors.newFixedThreadPool(20);
    public static void main(String[] args) throws  Exception{
        ClassPathXmlApplicationContext applicationContext  = new ClassPathXmlApplicationContext("classpath:dubbo-comsumer.xml");
        //applicationContext.start();
        HelloService  helloService  = applicationContext.getBean("helloService",HelloService.class);
        String result = helloService.sayHello("world");
        //System.out.println("result="+result);
       // System.in.read();
        MethodStatasticsUtil methodStatasticsUtil = new MethodStatasticsUtil();
        while (true){
            Random random = new Random();
            int i = random.nextInt(100);
            Thread.sleep(i);
            executorService.submit(()->{
                try {
                    helloService.sayHello("world");
                    helloService.sayHello1("world");
                    helloService.sayHello2("world");
                }
                catch (InterruptedException e) {
                    e.printStackTrace();
                }

            });
        }
    }
}
