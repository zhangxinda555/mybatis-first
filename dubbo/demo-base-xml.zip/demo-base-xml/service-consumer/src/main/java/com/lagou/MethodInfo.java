package com.lagou;

import java.time.LocalDateTime;

public class MethodInfo {

    private Long currentDateTime;

    private String methodName;

    private Long time;

    public Long getCurrentDateTime() {
        return currentDateTime;
    }

    public void setCurrentDateTime(Long currentDateTime) {
        this.currentDateTime = currentDateTime;
    }

    public String getMethodName() {
        return methodName;
    }

    public void setMethodName(String methodName) {
        this.methodName = methodName;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    @Override
    public String toString() {
        return "MethodInfo{" +
                "currentDateTime=" + currentDateTime +
                ", methodName='" + methodName + '\'' +
                ", time=" + time +
                '}';
    }
}
