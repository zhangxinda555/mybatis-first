package com.lagou;

import com.sun.org.apache.bcel.internal.generic.NEW;
import org.apache.dubbo.common.extension.SPI;
import org.apache.dubbo.rpc.Filter;
import org.apache.dubbo.rpc.Invocation;
import org.apache.dubbo.rpc.Invoker;
import org.apache.dubbo.rpc.Result;
import org.apache.dubbo.rpc.RpcException;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;


public class MyFilter implements Filter {
    @Override
    public Result invoke(Invoker <?> invoker, Invocation invocation) throws RpcException {
        long l = System.currentTimeMillis();
        //System.out.println("现在时间是:"+l);
        Result invoke = invoker.invoke(invocation);
        //System.out.println("结束时间是:"+System.currentTimeMillis()+",  总共花费了:"+(System.currentTimeMillis()-l));
        long l1 = System.currentTimeMillis()- l;

        String methodName = invocation.getMethodName();

        MethodInfo methodInfo = new MethodInfo();
        methodInfo.setCurrentDateTime(l);
        methodInfo.setMethodName(methodName);
        methodInfo.setTime(l1);

        Map <String, List <MethodInfo>> methods = MethodStatasticsUtil.methods;

        if (!methods.containsKey(methodName)){
            methods.put(methodName,new ArrayList <>());
        }
        List <MethodInfo> methodInfos = methods.get(methodName);
        methodInfos.add(methodInfo);
        return invoke;
    }
}
