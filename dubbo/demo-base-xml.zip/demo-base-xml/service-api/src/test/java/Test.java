import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Test {


    public static void main(String[] args) {

       /* List<Map<String,Object>> maps = new ArrayList <>();
        Map<String,Object> map = new HashMap <>();
        map.put("xingming","zhangxinda");
        map.put("data",new Date());

        Map<String,Object> map1 = new HashMap <>();
        map1.put("xingming","zhangxindaw");
        map1.put("data",new Date());
        maps.add(map);
        maps.add(map1);

        System.out.println(map1);
        System.out.println(map);

        Map <String, Object> map2 = maps.stream().collect(Collectors.maxBy(new Comparator <Map <String, Object>>() {
            @Override
            public int compare(Map <String, Object> o1, Map <String, Object> o2) {
                Date date1 = (Date) o1.get("data");
                Date date2 = (Date) o2.get("data");
                return date1.compareTo(date2);
            }
        })).get();
        System.out.println(map2);*/

        /*Instant instant = new Date().toInstant();
        DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDateTime localDateTime = LocalDateTime.ofInstant(instant, ZoneId.systemDefault());
        System.out.println(localDateTime);*/
        final Integer a ;
        List<Integer> list = new ArrayList <>();
        list.add(1);
        a=1;
        list.stream().forEach(e->{

            System.out.println(a);
        });



    }
}
