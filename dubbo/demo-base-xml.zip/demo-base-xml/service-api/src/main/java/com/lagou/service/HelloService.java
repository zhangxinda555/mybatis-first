package com.lagou.service;

public interface HelloService {
    String  sayHello(String name) throws InterruptedException;

    String  sayHello1(String name);

    String  sayHello2(String name);
}
