package com.lagou.service;


public interface Action {


    String sayHello();

    String sayName();
}
