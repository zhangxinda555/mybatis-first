package com.lagou.service.impl;


import com.lagou.service.Action;

public class HumanAction implements Action {
    @Override
    public String sayHello() {
        return "你好";
    }

    @Override
    public String sayName() {
        return "小强";
    }
}
