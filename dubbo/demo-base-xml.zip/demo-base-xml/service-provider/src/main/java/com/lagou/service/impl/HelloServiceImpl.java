package com.lagou.service.impl;

import com.lagou.service.HelloService;

import java.util.Random;

public class HelloServiceImpl  implements HelloService {
    @Override
    public String sayHello(String name)  {
        Random random = new Random();
        int i = random.nextInt(100);
        try {
            Thread.sleep(i);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return "hello:"+name;
    }

    @Override
    public String sayHello1(String name) {
        Random random = new Random();
        int i = random.nextInt(100);
        try {
            Thread.sleep(i);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return "hello:"+name;
    }

    @Override
    public String sayHello2(String name) {
        //Random random = new Random();
        //int i = random.nextInt(100);
        /*try {
            Thread.sleep(i);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }*/
        return "hello:"+name;
    }
}
