import org.apache.dubbo.common.URL;
import org.apache.dubbo.common.extension.ExtensionLoader;
import service.Action;

import java.io.UnsupportedEncodingException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

public class Test {

    private static ExecutorService executorService = Executors.newFixedThreadPool(4, new ThreadFactory() {
        private AtomicInteger atomicInteger = new AtomicInteger(0);
        @Override
        public Thread newThread(Runnable r) {
            Thread thread = new Thread(r,"repeat-pool" + atomicInteger.incrementAndGet());
            return thread;
        }
    });

    public static void main(String[] args) throws UnsupportedEncodingException {
        Action adaptiveExtension = ExtensionLoader.getExtensionLoader(Action.class).getAdaptiveExtension();
        URL url =URL.valueOf("dubbo://10.8.0.190:20882/com.lagou.service.HelloService?action=human");
        String s9 = adaptiveExtension.sayHello(url);
        System.out.println(s9);
        String a= "rqwr=, ";
        int i = a.indexOf(61);
        int i1 = a.indexOf(35);
        System.out.println(i);
        System.out.println(i1);
       /* List<Integer> list = new ArrayList <>();

        list.add(1);
        list.add(2);

        List <Integer> collect = list.stream().sorted((e1, e2) -> {
            return -1;
        }).collect(Collectors.toList());
        System.out.println(collect);

        List <Integer> collect1 = list.stream().sorted((e1, e2) -> {
            return 1;
        }).collect(Collectors.toList());
        System.out.println(collect1);*/
      /* String s = "700";
       String s1 = "700.0";
        Boolean a = Pattern.matches("^[0-9]+.?[0-9]*$",s) && Pattern.matches("^[0-9]+.?[0-9]*$",s1) &&
                new BigDecimal(s).compareTo(new BigDecimal(s1))==0;
        Boolean b = Pattern.matches("^[0-9]+.?[0-9]*$",s);
        Boolean c =  Pattern.matches("^[0-9]+.?[0-9]*$",s1) ;
        Boolean  d=  new BigDecimal(s).compareTo(new BigDecimal(s1))==0 ;
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);

        Long s2 = Math.round(Double.valueOf(s1));
        System.out.println(s2);
        Object value1 = "123.00";
        if (value1 != null && Pattern.matches("^[0-9]+.?[0]*$",value1.toString())){
            Long aLong = Long.valueOf(Math.round(Double.valueOf(value1.toString())));
            value1 = aLong.toString();
        }
        System.out.println(value1);

        System.out.println(s2.toString().toString());


        List lists = new ArrayList();
        lists.add("q15");
        lists.add("1");
        lists.add("24");
        lists.add("21");
        lists.add("z54");
        lists.add("145");
        lists.add("6");
        lists.add("11");
        lists.add("q14");
        System.out.println(lists);
        Collections.sort(lists);
        System.out.println(lists);


        Double a11 = 0.0 ;
        BigDecimal bigDecima = new BigDecimal(a11).setScale(2,BigDecimal.ROUND_HALF_UP);
        System.out.println(bigDecima.doubleValue());*/
        /*DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM");
        DateTimeFormatter dfs = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        Date date = new Date();
        Instant instant = date.toInstant();
        LocalDateTime localDateTime = LocalDateTime.ofInstant(instant, ZoneId.systemDefault());
        String format = localDateTime.format(dfs);
        LocalDate parse = LocalDate.parse(format,df);
        System.out.println(parse);*/
        /*List<Integer> list = Collections.synchronizedList(new ArrayList <>());
        list.add(0);
        final AtomicInteger atomicInteger = new AtomicInteger(0);


        for (int i =0;i<1000;i++){
            executorService.submit(new Runnable() {
                @Override
                public void run() {
                    int i = atomicInteger.incrementAndGet();
                    list.add(list.remove(0) + 1);

                    System.out.println("-----" + i);

                    System.out.println("--yyyy---" + list);
                }
            });
        }
        System.out.println(list);*/


       /* List list = new ArrayList();
        *//*list.add("");
        list.add(null);
        list.add("1235g");
        list.add("rer");*//*
        List list1 = list.subList(0, 0);
        System.out.println(list1);
        Collections.sort(list);
        System.out.println(list);*/
    }
}
