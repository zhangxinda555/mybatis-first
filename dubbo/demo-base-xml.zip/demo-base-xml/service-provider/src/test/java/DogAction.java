import org.apache.dubbo.common.URL;
import service.Action;

public class DogAction implements Action {
    @Override
    public String sayHello(URL url) {
        return "wang wang";
    }

    @Override
    public String sayName() {
        return "xiao wang";
    }
}
