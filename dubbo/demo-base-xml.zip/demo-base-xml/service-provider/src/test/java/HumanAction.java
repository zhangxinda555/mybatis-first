import org.apache.dubbo.common.URL;
import service.Action;

public class HumanAction implements Action {
    @Override
    public String sayHello(URL url) {
        return "你好";
    }

    @Override
    public String sayName() {
        return "小强";
    }
}
