package com.lagou.edu.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("data")
public class ListController {
    @RequestMapping("/list")
    public String result(){
        return "list";
    }
}
