package com.lagou.edu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SssSpringbootApplicationTests {

    @Test
    void contextLoads() {
    }

}
